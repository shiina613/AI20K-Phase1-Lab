"""
Day 1 — LLM API Foundation
AICB-P1: AI Practical Competency Program, Phase 1

Instructions:
    1. Fill in every section marked with TODO.
    2. Do NOT change function signatures.
    3. Copy this file to solution/solution.py when done.
    4. Run: pytest tests/ -v
"""

import os
import time
from typing import Any, Callable
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------------------------
# Estimated costs per 1K OUTPUT tokens (USD)
# ---------------------------------------------------------------------------
COST_PER_1K_OUTPUT_TOKENS = {
    "gpt-4o": 0.010,
    "gpt-4o-mini": 0.0006,
}

OPENAI_MODEL = "gpt-4o"
OPENAI_MINI_MODEL = "gpt-4o-mini"


# ---------------------------------------------------------------------------
# Task 1 — Call GPT-4o
# ---------------------------------------------------------------------------
def call_openai(
    prompt: str = "What is the capital of France?",
    model: str = OPENAI_MODEL,
    temperature: float = 0.7,
    top_p: float = 0.9,
    max_tokens: int = 256,
) -> tuple[str, float]:
    """
    Call the OpenAI Chat Completions API and return the response text + latency.
    """
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    
    start_time = time.perf_counter()
    
    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=temperature,
        top_p=top_p,
        max_tokens=max_tokens,
    )
    
    latency = time.perf_counter() - start_time
    response_text = response.choices[0].message.content
    
    return response_text, latency


# ---------------------------------------------------------------------------
# Task 2 — Call GPT-4o-mini
# ---------------------------------------------------------------------------
def call_openai_mini(
    prompt: str = "What is the capital of France?",
    model: str = OPENAI_MINI_MODEL,
    temperature: float = 0.7,
    top_p: float = 0.9,
    max_tokens: int = 256,
) -> tuple[str, float]:
    """
    Call the OpenAI Chat Completions API using gpt-4o-mini.
    """
    # Tái sử dụng hàm call_openai với model mini
    return call_openai(
        prompt=prompt,
        model=model,
        temperature=temperature,
        top_p=top_p,
        max_tokens=max_tokens
    )


# ---------------------------------------------------------------------------
# Task 3 — Compare GPT-4o vs GPT-4o-mini
# ---------------------------------------------------------------------------
def compare_models(prompt: str) -> dict:
    # Phải gọi chính xác 2 hàm này để Mock của test case bắt được
    res_4o, lat_4o = call_openai(prompt, model=OPENAI_MODEL)
    res_mini, lat_mini = call_openai_mini(prompt) # <--- Gọi call_openai_mini ở đây

    # Logic tính chi phí
    word_count = len(res_4o.split())
    estimated_tokens = word_count / 0.75
    gpt4o_cost = (estimated_tokens / 1000) * COST_PER_1K_OUTPUT_TOKENS["gpt-4o"]

    return {
        "gpt4o_response": res_4o,
        "mini_response": res_mini,
        "gpt4o_latency": lat_4o,
        "mini_latency": lat_mini,
        "gpt4o_cost_estimate": float(gpt4o_cost)
    }


# ---------------------------------------------------------------------------
# Task 4 — Streaming chatbot with conversation history
# ---------------------------------------------------------------------------
def streaming_chatbot() -> None:
    """
    Interactive streaming chatbot with 3-turn history.
    """
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    messages = [] # Danh sách lưu lịch sử hội thoại

    print("\n--- Chatbot Ready (Type 'quit' to exit) ---")
    
    while True:
        user_input = input("\nYou: ")
        if user_input.lower() in ["exit", "quit"]:
            break

        # Thêm tin nhắn người dùng vào lịch sử
        messages.append({"role": "user", "content": user_input})
        
        # Duy trì 3 lượt gần nhất (3 cặp User/Assistant = 6 tin nhắn)
        if len(messages) > 6:
            messages = messages[-6:]

        print("AI: ", end="", flush=True)
        
        # Gọi API với stream=True
        stream = client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=messages,
            stream=True
        )
        
        full_response = ""
        for chunk in stream:
            content = chunk.choices[0].delta.content
            if content:
                print(content, end="", flush=True)
                full_response += content
        
        print() # Xuống dòng
        # Lưu câu trả lời của AI vào lịch sử
        messages.append({"role": "assistant", "content": full_response})


# ---------------------------------------------------------------------------
# Bonus Task A — Retry with exponential backoff
# ---------------------------------------------------------------------------
def retry_with_backoff(
    fn: Callable,
    max_retries: int = 3,
    base_delay: float = 0.1,
) -> Any:
    last_exception = None
    for attempt in range(max_retries + 1):
        try:
            return fn()
        except Exception as e:
            last_exception = e
            if attempt == max_retries:
                break
            delay = base_delay * (2 ** attempt)
            print(f"Error! Retrying in {delay}s...")
            time.sleep(delay)
    
    raise last_exception


# ---------------------------------------------------------------------------
# Bonus Task B — Batch compare
# ---------------------------------------------------------------------------
def batch_compare(prompts: list[str]) -> list[dict]:
    results = []
    for p in prompts:
        res = compare_models(p)
        res["prompt"] = p
        results.append(res)
    return results


# ---------------------------------------------------------------------------
# Bonus Task C — Format comparison table
# ---------------------------------------------------------------------------
def format_comparison_table(results: list[dict]) -> str:
    col_w = 30
    header = f"{'Prompt':<{col_w}} | {'GPT-4o':<{col_w}} | {'Mini':<{col_w}} | {'Lat 4o':<8} | {'Lat Mini':<8}"
    sep = "-" * len(header)
    
    lines = [header, sep]
    for r in results:
        p = (r['prompt'][:col_w-3] + '...') if len(r['prompt']) > col_w else r['prompt']
        r4 = (r['gpt4o_response'][:col_w-3] + '...') if len(r['gpt4o_response']) > col_w else r['gpt4o_response']
        rm = (r['mini_response'][:col_w-3] + '...') if len(r['mini_response']) > col_w else r['mini_response']
        
        line = f"{p:<{col_w}} | {r4:<{col_w}} | {rm:<{col_w}} | {r['gpt4o_latency']:<8.2f} | {r['mini_latency']:<8.2f}"
        lines.append(line)
        
    return "\n".join(lines)


if __name__ == "__main__":
    # Chạy test thử nghiệm
    test_prompt = "Tại sao bầu trời màu xanh?"
    print("=== So sánh model ===")
    print(compare_models(test_prompt))
    
    print("\n=== Chatbot (Gõ 'quit' để thoát) ===")
    streaming_chatbot()