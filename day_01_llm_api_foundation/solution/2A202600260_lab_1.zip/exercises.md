# Ngày 1 — Bài Tập & Phản Ánh
## Nền Tảng LLM API | Phiếu Thực Hành

**Thời lượng:** 1:30 giờ  
**Cấu trúc:** Lập trình cốt lõi (60 phút) → Bài tập mở rộng (30 phút)

---

## Phần 1 — Lập Trình Cốt Lõi (0:00–1:00)

Chạy các ví dụ trong Google Colab tại: https://colab.research.google.com/drive/172zCiXpLr1FEXMRCAbmZoqTrKiSkUERm?usp=sharing

Triển khai tất cả TODO trong `template.py`. Chạy `pytest tests/` để kiểm tra tiến độ.

**Điểm kiểm tra:** Sau khi hoàn thành 4 nhiệm vụ, chạy:
```bash
python template.py
```
Bạn sẽ thấy output so sánh phản hồi của GPT-4o và GPT-4o-mini.

---

## Phần 2 — Bài Tập Mở Rộng (1:00–1:30)

### Bài tập 2.1 — Độ Nhạy Của Temperature
Gọi `call_openai` với các giá trị temperature 0.0, 0.5, 1.0 và 1.5 sử dụng prompt **"Hãy kể cho tôi một sự thật thú vị về Việt Nam."**

**Bạn nhận thấy quy luật gì qua bốn phản hồi?** (2–3 câu)
> Qua bốn mức độ temperature, tôi nhận thấy khi temperature thấp (0.0 và 0.5), phản hồi rất nhất quán, tập trung vào các sự thật lịch sử hoặc địa lý rõ ràng. Khi temperature tăng lên (1.0 và 1.5), cách hành văn trở nên bay bổng hơn, sử dụng nhiều tính từ cảm xúc hơn, tuy nhiên ở mức 1.5 câu trả lời có dấu hiệu bắt đầu bị lặp từ hoặc cấu trúc câu trở nên kém logic hơn một chút.

**Bạn sẽ đặt temperature bao nhiêu cho chatbot hỗ trợ khách hàng, và tại sao?**
> Tôi sẽ đặt temperature từ 0.0 đến 0.2. Bởi vì trong hỗ trợ khách hàng, sự chính xác và tính nhất quán (reliability) là quan trọng nhất; chatbot cần đưa ra các câu trả lời dựa trên sự thật và thông tin có sẵn thay vì sáng tạo thêm nội dung có thể gây hiểu lầm cho người dùng.

---

### Bài tập 2.2 — Đánh Đổi Chi Phí
Xem xét kịch bản: 10.000 người dùng hoạt động mỗi ngày, mỗi người thực hiện 3 lần gọi API, mỗi lần trung bình ~350 token.

**Ước tính xem GPT-4o đắt hơn GPT-4o-mini bao nhiêu lần cho workload này:**
> Đơn giá đầu ra của GPT-4o là $0.010/1K token, còn GPT-4o-mini là $0.0006/1K token. Như vậy, với cùng một lượng token tiêu thụ, GPT-4o đắt hơn GPT-4o-mini khoảng 16.67 lần. (Cụ thể cho workload này: 10.5 triệu token mỗi ngày sẽ tốn khoảng $105 với GPT-4o so với chỉ $6.3 với GPT-4o-mini)

**Mô tả một trường hợp mà chi phí cao hơn của GPT-4o là xứng đáng, và một trường hợp GPT-4o-mini là lựa chọn tốt hơn:**
> GPT-4o xứng đáng: Khi cần thực hiện các tác vụ suy luận phức tạp như phân tích logic mã nguồn (coding), giải quyết các bài toán toán học chuyên sâu, hoặc phân tích dữ liệu đa phương thức cần độ chính xác cực cao.

GPT-4o-mini tốt hơn: Khi triển khai các chatbot đàm thoại thông thường, tóm tắt văn bản ngắn, phân loại email (classification), hoặc các ứng dụng cần phản hồi cực nhanh với chi phí vận hành thấp cho số lượng người dùng lớn.

---

### Bài tập 2.3 — Trải Nghiệm Người Dùng với Streaming
**Streaming quan trọng nhất trong trường hợp nào, và khi nào thì non-streaming lại phù hợp hơn?** (1 đoạn văn)
> Streaming quan trọng nhất trong các ứng dụng chatbot tương tác trực tiếp (như ChatGPT), nơi phản hồi có thể dài; việc hiển thị token ngay khi chúng được sinh ra giúp giảm "độ trễ nhận thức" (perceived latency), khiến người dùng cảm thấy hệ thống phản hồi ngay lập tức. Ngược lại, non-streaming phù hợp hơn cho các tác vụ xử lý ngầm (background jobs) như phân tích dữ liệu hàng loạt, trích xuất thông tin theo định dạng JSON để đưa vào database, hoặc khi cần kiểm duyệt toàn bộ nội dung (content moderation) trước khi hiển thị cho người dùng.


## Danh Sách Kiểm Tra Nộp Bài
- [ ] Tất cả tests pass: `pytest tests/ -v`
- [ ] `call_openai` đã triển khai và kiểm thử
- [ ] `call_openai_mini` đã triển khai và kiểm thử
- [ ] `compare_models` đã triển khai và kiểm thử
- [ ] `streaming_chatbot` đã triển khai và kiểm thử
- [ ] `retry_with_backoff` đã triển khai và kiểm thử
- [ ] `batch_compare` đã triển khai và kiểm thử
- [ ] `format_comparison_table` đã triển khai và kiểm thử
- [ ] `exercises.md` đã điền đầy đủ
- [ ] Sao chép bài làm vào folder `solution` và đặt tên theo quy định 
